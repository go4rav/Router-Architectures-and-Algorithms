Used dijkstra algorithm to find shortest paths 
considered bidirectional links.

Contains only one source code file routing.cpp

Directly run makefile for execution

or

	g++ routing.cpp (for compilation)
    
    ./a.out -top topologyfile -conn connectionsfile -rt routingtablefile -ft forwardingfile -path pathsfile (for execution).



Sir, i am dealing with Makefiles for the first time, if there is any error, please make me prepare the Makefile once more.
Also, sir this is the first assignment, please excuse the ouput format. Next time, there will be proper output format.
Also, proper commenting will also be done. Thankyou.